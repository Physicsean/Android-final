package com.example.afinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;



public class Heroscape extends AppCompatActivity {

    private Button set20;
    private Button set40;
    private Button set25;
    private Button life1p;
    private Button life1m;
    private Button life2p;
    private Button life2m;
    private Button exit;

    private TextView tvlife1 ;
    private TextView tvlife2 ;





    int life1=20;
    int life2 = 20;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.life_couter);
        set20=(Button)findViewById( R.id.set20btn);
        set40=(Button)findViewById( R.id.sset40btn);
        set25=(Button)findViewById( R.id.set25btn);
        life1p=(Button)findViewById( R.id.life1plus);
        life1m=(Button)findViewById( R.id.life1_minus);
        life2p=(Button)findViewById( R.id.life2_plus);
        life2m=(Button)findViewById( R.id.life2m);
        exit=(Button)findViewById( R.id.returners);

        tvlife1=(TextView) findViewById(R.id.life1);
        tvlife2=(TextView)findViewById(R.id.life2);

        tvlife1.setText(Integer.toString(life1));
        tvlife2.setText(Integer.toString(life2));

        set20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                life1=20;
                life2 = 20;
                tvlife1.setText(Integer.toString(life1));
                tvlife2.setText(Integer.toString(life2));
            }
        });

        set25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                life1=25;
                life2 = 25;
                tvlife1.setText(Integer.toString(life1));
                tvlife2.setText(Integer.toString(life2));
            }
        });

        set40.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                life1=40;
                life2 = 40;
                tvlife1.setText(Integer.toString(life1));
                tvlife2.setText(Integer.toString(life2));
            }
        });

        life1p.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               life1+=1;
               tvlife1.setText(Integer.toString(life1));
            }
        });

        life1m.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                life1-=1;
                tvlife1.setText(Integer.toString(life1));
            }
        });

        life2p.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                life2+=1;
                tvlife2.setText(Integer.toString(life2));
            }
        });

        life2m.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                life2-=1;
                tvlife2.setText(Integer.toString(life2));
            }
        });
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                returntomain();
            }
        });




    }
    public void returntomain()
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
