package com.example.afinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.Random;
public class Dice extends AppCompatActivity {

    public Button P4;
    public Button M4;
    public TextView T4;

    public Button P6;
    public Button M6;
    public TextView T6;

    public Button P8;
    public Button M8;
    public TextView T8;

    public Button P10;
    public Button M10;
    public TextView T10;

    public Button P12;
    public Button M12;
    public TextView T12;

    public Button P20;
    public Button M20;
    public TextView T20;

    public Button clear;
    public Button Exit;
    public Button rollem;
    int num4 = 0;
    int num6 = 0;
    int num8 = 0;
    int num10 = 0;
    int num12 =0;
    int num20 =0;

    public TextView R4;
    public TextView R6;
    public TextView R8;
    public TextView R10;
    public TextView R12;
    public TextView R20;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dice);

        R4=(TextView)findViewById(R.id.r4);
        R6=(TextView)findViewById(R.id.r6);
        R8=(TextView)findViewById(R.id.r8);
        R10=(TextView)findViewById(R.id.r10);
        R12=(TextView)findViewById(R.id.r12);
        R20=(TextView)findViewById(R.id.r20);

        P4=(Button)findViewById(R.id.p4);
        M4=(Button)findViewById(R.id.m4);
        P6=(Button)findViewById(R.id.p6);
        M6=(Button)findViewById(R.id.m6);
        P8=(Button)findViewById(R.id.p8);
        M8=(Button)findViewById(R.id.p8);
        P10=(Button)findViewById(R.id.p10);
        M10=(Button)findViewById(R.id.m10);
        P12=(Button)findViewById(R.id.p12);
        M12=(Button)findViewById(R.id.m12);
        P20=(Button)findViewById(R.id.p20);
        M20=(Button)findViewById(R.id.m20);
        T4=(TextView)findViewById(R.id.tv4);
        T6=(TextView)findViewById(R.id.tv6);
        T8=(TextView)findViewById(R.id.tv8);
        T10=(TextView)findViewById(R.id.tv10);
        T12=(TextView)findViewById(R.id.tv12);
        T20=(TextView)findViewById(R.id.tv20);
        rollem=(Button)findViewById(R.id.roll);
        clear=(Button)findViewById(R.id.clear);
        Exit=(Button)findViewById(R.id.retuners);
        clears();

        rollem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            rolldice(4,num4,R4);
            rolldice(6,num6,R6);
            rolldice(8,num8,R8);
            rolldice(10,num10,R10);
            rolldice(12,num12,R12);
            rolldice(20,num20,R20);
            clears();
            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            clears();
            }
        });
        Exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            returnshome();
            }
        });
        P4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incr(num4,T4);
            }
        });
        P6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incr(num6,T6);
            }
        });

        P8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incr(num8,T8);
            }
        });

        P10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incr(num10,T10);
            }
        });

        P12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incr(num12,T12);
            }
        });
        P20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incr(num20,T20);
            }
        });

        M4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decr(num4,T4);
            }
        });
        M6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decr(num6,T6);
            }
        });

        M8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decr(num8,T8);
            }
        });

        M10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decr(num10,T10);
            }
        });

        M12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decr(num12,T12);
            }
        });
        M20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decr(num20,T20);
            }
        });


    }


public void returnshome()
{
    Intent intent = new Intent(this, MainActivity.class);
    startActivity(intent);
}
    public void clears()
    {
        int num4 = 0;
        int num6 = 0;
        int num8 = 0;
        int num10 = 0;
        int num12 =0;
        int num20 =0;
        T4.setText(Integer.toString(num4));
        T6.setText(Integer.toString(num6));
        T8.setText(Integer.toString(num8));
        T10.setText(Integer.toString(num10));
        T12.setText(Integer.toString(num12));
        T20.setText(Integer.toString(num20));
    }


    public void incr(int num, TextView tv)
    {
        num+=1;
        if(num>=4)
        {
            num =4;
        }
        tv.setText(Integer.toString(num));
    }

    public void decr(int num, TextView tv)
    {
        num -=1;
        if(num<=0)
        {
            num =0;
        }
        tv.setText(Integer.toString(num));
    }

    public void rolldice(int die, int num,TextView tv)
    {
        //tv.setText("");
        String hold =" ";
        Random rand = new Random();
     for( int i=0;i<num;i++)
     {
         int randval = rand.nextInt(die);
         hold= hold+" "+ Integer.toString(randval);


     }
     tv.setText(hold);

    }
}
