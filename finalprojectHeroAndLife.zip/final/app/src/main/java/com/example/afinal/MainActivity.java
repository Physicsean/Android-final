package com.example.afinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button heros;
    private Button rocks;
    private Button dice;
    private Button sets;
    private Button life;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = getIntent();
        setupUIViews();

        heros.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            openheroscape();
            }
        });

        rocks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        dice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opendice();
            }
        });

        sets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openheroscape();
            }
        });

        life.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openlife();
            }
        });

    }

    private void setupUIViews() {

        heros = (Button) findViewById(R.id.hsbtn);
        rocks = (Button) findViewById(R.id.rpsbtn);
        dice = (Button) findViewById(R.id.rdbtn);
        sets = (Button) findViewById(R.id.setbtn);
        life = (Button) findViewById(R.id.lcbtn);

    }
    private void openheroscape()
    {
        Intent intent = new Intent(this,Life.class);
        startActivity(intent);
    }
    private void openlife()
    {
        Intent intent = new Intent(this,Heroscape.class);
        startActivity(intent);
    }
    private void opendice()
    {
        Intent intent = new Intent(this,Dice.class);
        startActivity(intent);
    }
    private void opensettings()
    {
        Intent intent = new Intent(this,Settings.class);
        startActivity(intent);
    }
    private void openrps()
    {
        Intent intent = new Intent(this,Rock.class);
        startActivity(intent);
    }
}
