package com.example.afinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static java.lang.Integer.parseInt;

public class Life extends AppCompatActivity {


    private Button attackPlus;
    private Button attackMinus;
    private Button defencePlus;
    private Button defenceMinus;
    private Button exit;
    private Button Submit;
    private ListView data;

    private TextView attack_os;
    private TextView defence_os;
    int attack=5;
    int defense=3;

    ArrayList<Double> stats= new ArrayList<>();
    ArrayList<Double> atle= new ArrayList<>();
    ArrayList<String> toshow = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hscalc);
        Intent intent = getIntent();


        attackPlus=(Button)findViewById( R.id.a_plus);
        attackMinus=(Button)findViewById(R.id.a_minus);
        defencePlus=(Button)findViewById(R.id.d_plus);
        defenceMinus=(Button)findViewById(R.id.d_minus);
        exit=(Button)findViewById(R.id.leave);
        Submit=(Button)findViewById(R.id.subBtn);
        data=(ListView) findViewById(R.id.stat_view);
        attack_os=(TextView)findViewById(R.id.tv_attack);
        defence_os=(TextView)findViewById(R.id.tv_defence);

        defence_os.setText(Integer.toString(defense));
        attack_os.setText(Integer.toString(attack));


        attackPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addattack();
            }
        });
        attackMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                subattack();
            }
        });
        defencePlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               adddefence();
            }
        });
        defenceMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                subdefence();
            }
        });
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                returntomain();
            }
        });
        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculatate();
            }
        });

        data.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {//i is the position that is clicked
                double atleast =0;
                for(int piece =0;piece >i;piece++)
                {
                    atleast+= stats.indexOf(piece);
                }

                Toast.makeText(Life.this,Double.toString(atleast),Toast.LENGTH_SHORT).show();

            }
        });

    }



    public void addattack()
    {

        attack +=1;
        if (attack>=13)
        {
            attack =13;
        }
        attack_os.setText(Integer.toString(attack));
    }
    public void adddefence()
    {
        {

            defense +=1;
            if (defense>=13)
            {
                defense =13;
            }
            defence_os.setText(Integer.toString(defense));
        }
    }
    public void subattack()
    {
        {

            attack-=1;
            if (attack<=0)
            {
                attack =0;
            }
            attack_os.setText(Integer.toString(attack));
        }
    }
    public void subdefence()
    {
        {

            defense-=1;
            if (defense<=0)
            {
                defense =0;
            }
            defence_os.setText(Integer.toString(defense));
        }
    }
    public void returntomain() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void calculatate()
    {



        double skull=.5;
        double shield =(1.0/3.0);

        stats.clear();
        toshow.clear();

        for(int i=0;i<attack+1;i++)
        {
            stats.add(i, 0.0);
        }

        for(int i=0;i<attack+1;i++)
        {

            double Aodds = Px(attack,i,skull);


            for(int j=0;j<defense+1;j++)
            {
                double Bodds = Px(defense, j, shield);

                if ((i-j)<0)
                {
                    double hold = stats.get(0);
                    hold += Aodds * Bodds;
                    stats.set(0,hold);
                }
                else
                {
                    double hold = stats.get(i-j);
                    hold += Aodds * Bodds;
                    stats.set(i-j,hold);
                }

            }

        }

        for (int k=0; k<attack+1;k++)
        {
            double atle = 0;
            for(int d=0;d<k;d++)
            {
                atle += stats.get(d);
            }
            double frm1 =(1-atle)* 100;
            double frm =stats.get(k)*100;
            double frmatle = atle*100;

            String frm11= String.format("%.2f",frm);
            String frm22=String.format("%.2f",frm1);
           String frm33 = String.format("%.2f", frmatle);

            toshow.add(k, k +" Wounds: \nExact odds: " +frm11  +"%\nOdds to hit: "+ frm22+"%\nOdds to miss: "+frm33+"%");
        }
        ArrayAdapter arrayAdapter= new ArrayAdapter(this,android.R.layout.simple_list_item_1,toshow);
        data.setAdapter(arrayAdapter);
        // return 0;
    }

    static int fact(int k)
    {
        if ((k==0)||(k==1))
            return 1;
        else
            return k*fact(k-1);
    }

    static double Px(int n, int x, double p)
    {
        double a = (fact(n));

        // cout << a <<"\n";
        double b = (fact(x)* fact(n-x));
        //cout << b << "\n";
        double c = Math.pow(p,x) * Math.pow((1-p),(n-x));
        // cout << c <<"\n";


        double d = (a/b)*c;


        return d;
    }


}
